import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { CryptoPrices, WalletConnection, PaymentMethod } from '../types';
import { cryptoApi } from '../services/cryptoApi';
import { walletService } from '../services/walletService';

interface CryptoContextType {
  prices: CryptoPrices | null;
  selectedCurrency: string;
  setSelectedCurrency: (currency: string) => void;
  walletConnection: WalletConnection | null;
  connectWallet: (walletType: string) => Promise<void>;
  disconnectWallet: () => void;
  convertPrice: (usdPrice: number) => number;
  formatCryptoPrice: (amount: number) => string;
  paymentMethods: PaymentMethod[];
  loading: boolean;
  error: string | null;
}

const CryptoContext = createContext<CryptoContextType | undefined>(undefined);

export const CryptoProvider = ({ children }: { children: ReactNode }) => {
  const [prices, setPrices] = useState<CryptoPrices | null>(null);
  const [selectedCurrency, setSelectedCurrency] = useState('bitcoin');
  const [walletConnection, setWalletConnection] = useState<WalletConnection | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const paymentMethods = walletService.getSupportedPaymentMethods();

  useEffect(() => {
    const fetchPrices = async () => {
      try {
        setLoading(true);
        const cryptoPrices = await cryptoApi.getCryptoPrices();
        setPrices(cryptoPrices);
        setError(null);
      } catch (err) {
        setError('Failed to fetch cryptocurrency prices');
        console.error('Error fetching prices:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPrices();
    const interval = setInterval(fetchPrices, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const connectWallet = async (walletType: string) => {
    try {
      setLoading(true);
      let connection: WalletConnection | null = null;

      switch (walletType) {
        case 'metamask':
          connection = await walletService.connectMetaMask();
          break;
        case 'binance':
          connection = await walletService.connectBinanceWallet();
          break;
        case 'walletconnect':
          connection = await walletService.connectWalletConnect();
          break;
        default:
          throw new Error('Unsupported wallet type');
      }

      if (connection) {
        setWalletConnection(connection);
        setError(null);
      } else {
        throw new Error('Failed to connect wallet');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to connect wallet');
    } finally {
      setLoading(false);
    }
  };

  const disconnectWallet = () => {
    walletService.disconnect();
    setWalletConnection(null);
  };

  const convertPrice = (usdPrice: number): number => {
    if (!prices) return 0;
    
    const cryptoPrice = prices[selectedCurrency as keyof CryptoPrices];
    return cryptoApi.convertUSDToCrypto(usdPrice, cryptoPrice);
  };

  const formatCryptoPrice = (amount: number): string => {
    const currency = paymentMethods.find(p => p.id === selectedCurrency);
    const symbol = currency?.symbol || selectedCurrency.toUpperCase();
    
    if (selectedCurrency === 'bitcoin') {
      return `${cryptoApi.formatCryptoAmount(amount, 8)} ${symbol}`;
    } else if (selectedCurrency === 'ethereum') {
      return `${cryptoApi.formatCryptoAmount(amount, 6)} ${symbol}`;
    } else {
      return `${cryptoApi.formatCryptoAmount(amount, 4)} ${symbol}`;
    }
  };

  return (
    <CryptoContext.Provider value={{
      prices,
      selectedCurrency,
      setSelectedCurrency,
      walletConnection,
      connectWallet,
      disconnectWallet,
      convertPrice,
      formatCryptoPrice,
      paymentMethods,
      loading,
      error
    }}>
      {children}
    </CryptoContext.Provider>
  );
};

export const useCrypto = () => {
  const context = useContext(CryptoContext);
  if (!context) {
    throw new Error('useCrypto must be used within a CryptoProvider');
  }
  return context;
};