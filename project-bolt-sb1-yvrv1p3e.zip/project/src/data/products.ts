import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Premium Wireless Headphones',
    price: 0.0067, // BTC equivalent
    priceUSD: 299.99,
    originalPrice: 0.0089,
    originalPriceUSD: 399.99,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
    category: 'Electronics',
    rating: 4.8,
    reviews: 324,
    description: 'Experience exceptional sound quality with our premium wireless headphones featuring active noise cancellation and 30-hour battery life.',
    features: ['Active Noise Cancellation', '30-hour Battery', 'Hi-Fi Audio', 'Bluetooth 5.0'],
    inStock: true,
    badge: 'Sale'
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    price: 0.0044,
    priceUSD: 199.99,
    image: 'https://images.pexels.com/photos/267394/pexels-photo-267394.jpeg',
    category: 'Wearables',
    rating: 4.6,
    reviews: 189,
    description: 'Track your fitness journey with advanced health monitoring, GPS tracking, and smart notifications.',
    features: ['GPS Tracking', 'Heart Rate Monitor', '7-day Battery', 'Water Resistant'],
    inStock: true,
    badge: 'Popular'
  },
  {
    id: '3',
    name: 'Professional Camera Lens',
    price: 0.02,
    priceUSD: 899.99,
    image: 'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg',
    category: 'Photography',
    rating: 4.9,
    reviews: 76,
    description: 'Capture stunning photos with this professional-grade camera lens featuring superior optics and precision engineering.',
    features: ['F/1.4 Aperture', 'Image Stabilization', 'Weather Sealed', 'Ultra-Sharp Optics'],
    inStock: true,
    badge: 'New'
  },
  {
    id: '4',
    name: 'Minimalist Desk Setup',
    price: 0.0033,
    priceUSD: 149.99,
    image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg',
    category: 'Home Office',
    rating: 4.7,
    reviews: 203,
    description: 'Create the perfect workspace with this minimalist desk organizer featuring premium materials and thoughtful design.',
    features: ['Premium Wood', 'Cable Management', 'Multiple Compartments', 'Ergonomic Design'],
    inStock: true
  },
  {
    id: '5',
    name: 'Luxury Skincare Set',
    price: 0.0018,
    priceUSD: 79.99,
    originalPrice: 0.0027,
    originalPriceUSD: 120.00,
    image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
    category: 'Beauty',
    rating: 4.5,
    reviews: 412,
    description: 'Pamper your skin with our luxury skincare collection featuring natural ingredients and proven results.',
    features: ['Natural Ingredients', 'Dermatologist Tested', 'Cruelty Free', 'Anti-Aging Formula'],
    inStock: true,
    badge: 'Sale'
  },
  {
    id: '6',
    name: 'Artisan Coffee Beans',
    price: 0.00056,
    priceUSD: 24.99,
    image: 'https://images.pexels.com/photos/894695/pexels-photo-894695.jpeg',
    category: 'Food & Beverage',
    rating: 4.8,
    reviews: 156,
    description: 'Experience the perfect cup with our premium artisan coffee beans, carefully sourced and expertly roasted.',
    features: ['Single Origin', 'Fair Trade', 'Small Batch Roasted', 'Rich Flavor Profile'],
    inStock: true,
    badge: 'Popular'
  }
];

export const categories = [
  'All Products',
  'Electronics',
  'Wearables',
  'Photography',
  'Home Office',
  'Beauty',
  'Food & Beverage'
];