import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductGrid } from './components/ProductGrid';
import { Cart } from './components/Cart';
import { ProductModal } from './components/ProductModal';
import { Footer } from './components/Footer';
import { WalletConnector } from './components/WalletConnector';
import { CryptoPayment } from './components/CryptoPayment';
import { CryptoPriceDisplay } from './components/CryptoPriceDisplay';
import { CartProvider } from './hooks/useCart';
import { CryptoProvider } from './hooks/useCrypto';
import { products } from './data/products';
import { Product } from './types';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);

  // Filter products based on search query
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setIsProductModalOpen(true);
  };

  const handleCloseProductModal = () => {
    setIsProductModalOpen(false);
    setSelectedProduct(null);
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsPaymentOpen(true);
  };

  return (
    <CryptoProvider>
      <CartProvider>
        <div className="min-h-screen bg-white">
          <CryptoPriceDisplay />
          
          <Header 
            onSearchChange={setSearchQuery}
            onCartClick={() => setIsCartOpen(true)}
            onWalletClick={() => setIsWalletOpen(true)}
          />
          
          <main>
            <Hero />
            <ProductGrid 
              products={filteredProducts}
              onProductClick={handleProductClick}
            />
          </main>
          
          <Footer />
          
          <Cart 
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            onCheckout={handleCheckout}
          />
          
          <WalletConnector
            isOpen={isWalletOpen}
            onClose={() => setIsWalletOpen(false)}
          />
          
          <CryptoPayment
            isOpen={isPaymentOpen}
            onClose={() => setIsPaymentOpen(false)}
            totalAmount={0} // This will be calculated from cart
          />
          
          <ProductModal
            product={selectedProduct}
            isOpen={isProductModalOpen}
            onClose={handleCloseProductModal}
          />
        </div>
      </CartProvider>
    </CryptoProvider>
  );
}

export default App;