export interface Product {
  id: string;
  name: string;
  price: number;
  priceUSD: number;
  originalPrice?: number;
  originalPriceUSD?: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  description: string;
  features: string[];
  inStock: boolean;
  badge?: 'New' | 'Sale' | 'Popular';
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface CryptoPrices {
  bitcoin: number;
  ethereum: number;
  binancecoin: number;
  cardano: number;
  solana: number;
  dogecoin: number;
  litecoin: number;
  chainlink: number;
}

export interface WalletConnection {
  address: string;
  balance: string;
  network: string;
  connected: boolean;
}

export interface PaymentMethod {
  id: string;
  name: string;
  symbol: string;
  icon: string;
  network: string;
  contractAddress?: string;
}