import axios from 'axios';
import { CryptoPrices } from '../types';

const COINGECKO_API = 'https://api.coingecko.com/api/v3';
const BINANCE_API = 'https://api.binance.com/api/v3';

export class CryptoApiService {
  private static instance: CryptoApiService;
  private priceCache: Map<string, { price: number; timestamp: number }> = new Map();
  private readonly CACHE_DURATION = 30000; // 30 seconds

  static getInstance(): CryptoApiService {
    if (!CryptoApiService.instance) {
      CryptoApiService.instance = new CryptoApiService();
    }
    return CryptoApiService.instance;
  }

  async getCryptoPrices(): Promise<CryptoPrices> {
    try {
      const response = await axios.get(`${COINGECKO_API}/simple/price`, {
        params: {
          ids: 'bitcoin,ethereum,binancecoin,cardano,solana,dogecoin,litecoin,chainlink',
          vs_currencies: 'usd',
          include_24hr_change: true
        }
      });

      return {
        bitcoin: response.data.bitcoin.usd,
        ethereum: response.data.ethereum.usd,
        binancecoin: response.data.binancecoin.usd,
        cardano: response.data.cardano.usd,
        solana: response.data.solana.usd,
        dogecoin: response.data.dogecoin.usd,
        litecoin: response.data.litecoin.usd,
        chainlink: response.data.chainlink.usd
      };
    } catch (error) {
      console.error('Error fetching crypto prices:', error);
      // Return fallback prices
      return {
        bitcoin: 45000,
        ethereum: 2500,
        binancecoin: 300,
        cardano: 0.5,
        solana: 100,
        dogecoin: 0.08,
        litecoin: 70,
        chainlink: 15
      };
    }
  }

  async getBinancePrices(): Promise<Record<string, number>> {
    try {
      const response = await axios.get(`${BINANCE_API}/ticker/price`);
      const prices: Record<string, number> = {};
      
      response.data.forEach((ticker: any) => {
        if (ticker.symbol.endsWith('USDT')) {
          const symbol = ticker.symbol.replace('USDT', '').toLowerCase();
          prices[symbol] = parseFloat(ticker.price);
        }
      });

      return prices;
    } catch (error) {
      console.error('Error fetching Binance prices:', error);
      return {};
    }
  }

  async getTokenPrice(tokenSymbol: string): Promise<number> {
    const cacheKey = tokenSymbol.toLowerCase();
    const cached = this.priceCache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      return cached.price;
    }

    try {
      const response = await axios.get(`${COINGECKO_API}/simple/price`, {
        params: {
          ids: tokenSymbol.toLowerCase(),
          vs_currencies: 'usd'
        }
      });

      const price = response.data[tokenSymbol.toLowerCase()]?.usd || 0;
      this.priceCache.set(cacheKey, { price, timestamp: Date.now() });
      
      return price;
    } catch (error) {
      console.error(`Error fetching price for ${tokenSymbol}:`, error);
      return 0;
    }
  }

  convertUSDToCrypto(usdAmount: number, cryptoPrice: number): number {
    return usdAmount / cryptoPrice;
  }

  formatCryptoAmount(amount: number, decimals: number = 8): string {
    return amount.toFixed(decimals);
  }

  async getWalletBalance(address: string, network: string = 'ethereum'): Promise<string> {
    try {
      // This would integrate with actual blockchain APIs
      // For demo purposes, returning a mock balance
      return '1.234567';
    } catch (error) {
      console.error('Error fetching wallet balance:', error);
      return '0';
    }
  }
}

export const cryptoApi = CryptoApiService.getInstance();