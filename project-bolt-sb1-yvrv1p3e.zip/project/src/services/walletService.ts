import { WalletConnection, PaymentMethod } from '../types';

declare global {
  interface Window {
    ethereum?: any;
    binance?: any;
    solana?: any;
  }
}

export class WalletService {
  private static instance: WalletService;
  private connection: WalletConnection | null = null;

  static getInstance(): WalletService {
    if (!WalletService.instance) {
      WalletService.instance = new WalletService();
    }
    return WalletService.instance;
  }

  async connectMetaMask(): Promise<WalletConnection | null> {
    try {
      if (!window.ethereum) {
        throw new Error('MetaMask not installed');
      }

      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      });

      if (accounts.length === 0) {
        throw new Error('No accounts found');
      }

      const balance = await window.ethereum.request({
        method: 'eth_getBalance',
        params: [accounts[0], 'latest']
      });

      const balanceInEth = parseInt(balance, 16) / Math.pow(10, 18);

      this.connection = {
        address: accounts[0],
        balance: balanceInEth.toFixed(4),
        network: 'ethereum',
        connected: true
      };

      return this.connection;
    } catch (error) {
      console.error('Error connecting to MetaMask:', error);
      return null;
    }
  }

  async connectBinanceWallet(): Promise<WalletConnection | null> {
    try {
      if (!window.binance) {
        throw new Error('Binance Wallet not installed');
      }

      const accounts = await window.binance.request({
        method: 'eth_requestAccounts'
      });

      this.connection = {
        address: accounts[0],
        balance: '0.0000',
        network: 'binance-smart-chain',
        connected: true
      };

      return this.connection;
    } catch (error) {
      console.error('Error connecting to Binance Wallet:', error);
      return null;
    }
  }

  async connectWalletConnect(): Promise<WalletConnection | null> {
    try {
      // WalletConnect integration would go here
      // For demo purposes, returning a mock connection
      this.connection = {
        address: '0x742d35Cc6634C0532925a3b8D4C9db96590b5',
        balance: '2.5678',
        network: 'ethereum',
        connected: true
      };

      return this.connection;
    } catch (error) {
      console.error('Error connecting via WalletConnect:', error);
      return null;
    }
  }

  disconnect(): void {
    this.connection = null;
  }

  getConnection(): WalletConnection | null {
    return this.connection;
  }

  async sendTransaction(to: string, amount: string, currency: string): Promise<string> {
    try {
      if (!this.connection) {
        throw new Error('Wallet not connected');
      }

      if (!window.ethereum) {
        throw new Error('MetaMask not available');
      }

      const transactionParameters = {
        to,
        from: this.connection.address,
        value: (parseFloat(amount) * Math.pow(10, 18)).toString(16),
        gas: '21000',
      };

      const txHash = await window.ethereum.request({
        method: 'eth_sendTransaction',
        params: [transactionParameters],
      });

      return txHash;
    } catch (error) {
      console.error('Error sending transaction:', error);
      throw error;
    }
  }

  getSupportedPaymentMethods(): PaymentMethod[] {
    return [
      {
        id: 'bitcoin',
        name: 'Bitcoin',
        symbol: 'BTC',
        icon: '₿',
        network: 'bitcoin'
      },
      {
        id: 'ethereum',
        name: 'Ethereum',
        symbol: 'ETH',
        icon: 'Ξ',
        network: 'ethereum'
      },
      {
        id: 'binancecoin',
        name: 'BNB',
        symbol: 'BNB',
        icon: 'BNB',
        network: 'binance-smart-chain'
      },
      {
        id: 'usdt',
        name: 'Tether',
        symbol: 'USDT',
        icon: '₮',
        network: 'ethereum',
        contractAddress: '0xdAC17F958D2ee523a2206206994597C13D831ec7'
      },
      {
        id: 'usdc',
        name: 'USD Coin',
        symbol: 'USDC',
        icon: 'USDC',
        network: 'ethereum',
        contractAddress: '0xA0b86a33E6441b8e776f1b0b8c8b5b8e8b8e8b8e'
      }
    ];
  }
}

export const walletService = WalletService.getInstance();