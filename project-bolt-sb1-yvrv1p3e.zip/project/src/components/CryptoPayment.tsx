import React, { useState } from 'react';
import { X, CreditCard, Wallet, CheckCircle, AlertCircle, Copy } from 'lucide-react';
import { useCrypto } from '../hooks/useCrypto';
import { useCart } from '../hooks/useCart';
import { walletService } from '../services/walletService';

interface CryptoPaymentProps {
  isOpen: boolean;
  onClose: () => void;
  totalAmount: number;
}

export const CryptoPayment: React.FC<CryptoPaymentProps> = ({ isOpen, onClose, totalAmount }) => {
  const { selectedCurrency, setSelectedCurrency, convertPrice, formatCryptoPrice, paymentMethods, walletConnection } = useCrypto();
  const { clearCart } = useCart();
  const [paymentStep, setPaymentStep] = useState<'select' | 'confirm' | 'processing' | 'success' | 'error'>('select');
  const [transactionHash, setTransactionHash] = useState<string>('');
  const [error, setError] = useState<string>('');

  const cryptoAmount = convertPrice(totalAmount);
  const merchantAddress = '0x742d35Cc6634C0532925a3b8D4C9db96590b5';

  const handlePaymentMethodSelect = (methodId: string) => {
    setSelectedCurrency(methodId);
  };

  const handleConfirmPayment = async () => {
    if (!walletConnection) {
      setError('Please connect your wallet first');
      setPaymentStep('error');
      return;
    }

    setPaymentStep('processing');
    
    try {
      const txHash = await walletService.sendTransaction(
        merchantAddress,
        cryptoAmount.toString(),
        selectedCurrency
      );
      
      setTransactionHash(txHash);
      setPaymentStep('success');
      clearCart();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Payment failed');
      setPaymentStep('error');
    }
  };

  const copyTransactionHash = () => {
    navigator.clipboard.writeText(transactionHash);
  };

  const resetPayment = () => {
    setPaymentStep('select');
    setError('');
    setTransactionHash('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="absolute inset-4 bg-white rounded-xl shadow-2xl overflow-hidden max-w-2xl mx-auto">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
              <CreditCard className="h-5 w-5" />
              <span>Crypto Payment</span>
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="flex-1 p-6 overflow-y-auto">
            {paymentStep === 'select' && (
              <div className="space-y-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-medium text-gray-900">Total Amount:</span>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-gray-900">${totalAmount.toFixed(2)}</div>
                      <div className="text-sm text-gray-600">
                        ≈ {formatCryptoPrice(cryptoAmount)}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Select Payment Method</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {paymentMethods.map((method) => (
                      <button
                        key={method.id}
                        onClick={() => handlePaymentMethodSelect(method.id)}
                        className={`p-4 border-2 rounded-lg transition-all duration-200 ${
                          selectedCurrency === method.id
                            ? 'border-indigo-500 bg-indigo-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="text-center">
                          <div className="text-2xl mb-2">{method.icon}</div>
                          <div className="font-medium text-gray-900">{method.name}</div>
                          <div className="text-sm text-gray-600">{method.symbol}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {walletConnection ? (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span className="font-medium text-green-800">Wallet Connected</span>
                    </div>
                    <p className="text-sm text-green-700 mt-1">
                      {walletConnection.address.slice(0, 6)}...{walletConnection.address.slice(-4)}
                    </p>
                  </div>
                ) : (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2">
                      <Wallet className="h-5 w-5 text-yellow-600" />
                      <span className="font-medium text-yellow-800">Connect Wallet Required</span>
                    </div>
                    <p className="text-sm text-yellow-700 mt-1">
                      Please connect your wallet to proceed with payment
                    </p>
                  </div>
                )}

                <button
                  onClick={handleConfirmPayment}
                  disabled={!walletConnection}
                  className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-indigo-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Confirm Payment
                </button>
              </div>
            )}

            {paymentStep === 'processing' && (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Processing Payment</h3>
                <p className="text-gray-600">Please confirm the transaction in your wallet...</p>
              </div>
            )}

            {paymentStep === 'success' && (
              <div className="text-center py-12">
                <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Payment Successful!</h3>
                <p className="text-gray-600 mb-6">Your order has been confirmed and is being processed.</p>
                
                <div className="bg-gray-50 p-4 rounded-lg mb-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Transaction Hash:</span>
                    <button
                      onClick={copyTransactionHash}
                      className="text-indigo-600 hover:text-indigo-700 transition-colors duration-200"
                    >
                      <Copy className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="text-sm font-mono text-gray-900 mt-1 break-all">
                    {transactionHash}
                  </div>
                </div>

                <button
                  onClick={onClose}
                  className="bg-indigo-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-indigo-700 transition-colors duration-200"
                >
                  Continue Shopping
                </button>
              </div>
            )}

            {paymentStep === 'error' && (
              <div className="text-center py-12">
                <AlertCircle className="h-16 w-16 text-red-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Payment Failed</h3>
                <p className="text-gray-600 mb-6">{error}</p>
                
                <div className="space-y-3">
                  <button
                    onClick={resetPayment}
                    className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-indigo-700 transition-colors duration-200"
                  >
                    Try Again
                  </button>
                  <button
                    onClick={onClose}
                    className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg font-medium hover:bg-gray-50 transition-colors duration-200"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};