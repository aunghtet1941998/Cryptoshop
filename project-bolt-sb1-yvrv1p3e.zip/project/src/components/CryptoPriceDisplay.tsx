import React from 'react';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { useCrypto } from '../hooks/useCrypto';

export const CryptoPriceDisplay: React.FC = () => {
  const { prices, loading, error } = useCrypto();

  if (loading) {
    return (
      <div className="bg-gray-900 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="animate-pulse text-sm">Loading crypto prices...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !prices) {
    return (
      <div className="bg-red-900 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="text-sm">Unable to load crypto prices</div>
          </div>
        </div>
      </div>
    );
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: price < 1 ? 4 : 2,
      maximumFractionDigits: price < 1 ? 4 : 2
    }).format(price);
  };

  const cryptoData = [
    { name: 'BTC', price: prices.bitcoin, icon: '₿' },
    { name: 'ETH', price: prices.ethereum, icon: 'Ξ' },
    { name: 'BNB', price: prices.binancecoin, icon: 'BNB' },
    { name: 'ADA', price: prices.cardano, icon: 'ADA' },
    { name: 'SOL', price: prices.solana, icon: 'SOL' },
    { name: 'DOGE', price: prices.dogecoin, icon: 'Ð' }
  ];

  return (
    <div className="bg-gray-900 text-white py-2 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-8 animate-scroll">
          <div className="flex items-center space-x-2 text-sm font-medium">
            <DollarSign className="h-4 w-4 text-green-400" />
            <span>Live Crypto Prices</span>
          </div>
          
          {cryptoData.map((crypto, index) => (
            <div key={crypto.name} className="flex items-center space-x-2 text-sm whitespace-nowrap">
              <span className="font-bold text-yellow-400">{crypto.icon}</span>
              <span className="font-medium">{crypto.name}</span>
              <span className="text-green-400">{formatPrice(crypto.price)}</span>
            </div>
          ))}
        </div>
      </div>
      
      <style jsx>{`
        @keyframes scroll {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        .animate-scroll {
          animation: scroll 30s linear infinite;
        }
      `}</style>
    </div>
  );
};