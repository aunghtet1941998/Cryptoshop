import React, { useState } from 'react';
import { Search, ShoppingCart, User, Menu, X, Wallet } from 'lucide-react';
import { useCart } from '../hooks/useCart';
import { useCrypto } from '../hooks/useCrypto';

interface HeaderProps {
  onSearchChange: (query: string) => void;
  onCartClick: () => void;
  onWalletClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSearchChange, onCartClick, onWalletClick }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { getTotalItems } = useCart();
  const { walletConnection, selectedCurrency, paymentMethods } = useCrypto();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    onSearchChange(query);
  };

  const totalItems = getTotalItems();
  const currentCurrency = paymentMethods.find(p => p.id === selectedCurrency);

  return (
    <>
      {/* Crypto Price Ticker */}
      <div className="bg-gray-900 text-white py-2 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center text-sm">
            <span className="animate-pulse">🚀 Now accepting Bitcoin, Ethereum, BNB and more cryptocurrencies!</span>
          </div>
        </div>
      </div>

      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  CryptoShop
                </h1>
              </div>
            </div>

            {/* Search Bar - Desktop */}
            <div className="hidden md:block flex-1 max-w-2xl mx-8">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg leading-5 bg-gray-50 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
                />
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              {/* Currency Display */}
              <div className="flex items-center space-x-2 text-sm">
                <span className="text-gray-600">Paying with:</span>
                <div className="flex items-center space-x-1 bg-indigo-50 px-2 py-1 rounded-lg">
                  <span className="font-bold text-indigo-600">{currentCurrency?.icon}</span>
                  <span className="font-medium text-indigo-600">{currentCurrency?.symbol}</span>
                </div>
              </div>

              {/* Wallet Connection */}
              <button
                onClick={onWalletClick}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-200 ${
                  walletConnection
                    ? 'bg-green-50 text-green-700 border border-green-200'
                    : 'bg-gray-50 text-gray-700 border border-gray-200 hover:border-indigo-200 hover:text-indigo-600'
                }`}
              >
                <Wallet className="h-4 w-4" />
                <span className="text-sm font-medium">
                  {walletConnection 
                    ? `${walletConnection.address.slice(0, 6)}...${walletConnection.address.slice(-4)}`
                    : 'Connect Wallet'
                  }
                </span>
              </button>

              <button className="text-gray-700 hover:text-indigo-600 transition-colors duration-200 flex items-center space-x-1">
                <User className="h-5 w-5" />
                <span className="text-sm font-medium">Account</span>
              </button>

              <button
                onClick={onCartClick}
                className="relative text-gray-700 hover:text-indigo-600 transition-colors duration-200 flex items-center space-x-1"
              >
                <ShoppingCart className="h-5 w-5" />
                <span className="text-sm font-medium">Cart</span>
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-indigo-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                    {totalItems}
                  </span>
                )}
              </button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-gray-700 hover:text-indigo-600 transition-colors duration-200"
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Search */}
          <div className="md:hidden py-3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg leading-5 bg-gray-50 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden border-t border-gray-100 py-4">
              <div className="flex flex-col space-y-4">
                <div className="flex items-center justify-between px-2">
                  <span className="text-sm text-gray-600">Currency:</span>
                  <div className="flex items-center space-x-1 bg-indigo-50 px-2 py-1 rounded-lg">
                    <span className="font-bold text-indigo-600">{currentCurrency?.icon}</span>
                    <span className="font-medium text-indigo-600">{currentCurrency?.symbol}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onWalletClick();
                    setIsMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 px-2 py-2 rounded-lg transition-all duration-200 ${
                    walletConnection
                      ? 'bg-green-50 text-green-700'
                      : 'text-gray-700 hover:text-indigo-600'
                  }`}
                >
                  <Wallet className="h-5 w-5" />
                  <span>
                    {walletConnection 
                      ? `Wallet Connected`
                      : 'Connect Wallet'
                    }
                  </span>
                </button>

                <button className="text-gray-700 hover:text-indigo-600 transition-colors duration-200 flex items-center space-x-2 px-2">
                  <User className="h-5 w-5" />
                  <span>Account</span>
                </button>

                <button
                  onClick={() => {
                    onCartClick();
                    setIsMobileMenuOpen(false);
                  }}
                  className="relative text-gray-700 hover:text-indigo-600 transition-colors duration-200 flex items-center space-x-2 px-2"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>Cart ({totalItems})</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </header>
    </>
  );
};