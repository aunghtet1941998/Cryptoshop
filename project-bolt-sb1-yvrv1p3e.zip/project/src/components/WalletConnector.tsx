import React, { useState } from 'react';
import { Wallet, X, CheckCircle, AlertCircle, Copy, ExternalLink } from 'lucide-react';
import { useCrypto } from '../hooks/useCrypto';

interface WalletConnectorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WalletConnector: React.FC<WalletConnectorProps> = ({ isOpen, onClose }) => {
  const { walletConnection, connectWallet, disconnectWallet, loading, error } = useCrypto();
  const [connecting, setConnecting] = useState<string | null>(null);

  const handleConnect = async (walletType: string) => {
    setConnecting(walletType);
    try {
      await connectWallet(walletType);
      if (walletConnection) {
        onClose();
      }
    } catch (err) {
      console.error('Connection failed:', err);
    } finally {
      setConnecting(null);
    }
  };

  const copyAddress = () => {
    if (walletConnection?.address) {
      navigator.clipboard.writeText(walletConnection.address);
    }
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
              <Wallet className="h-5 w-5" />
              <span>Connect Wallet</span>
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="flex-1 p-6">
            {walletConnection ? (
              /* Connected State */
              <div className="space-y-6">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="font-medium text-green-800">Wallet Connected</span>
                  </div>
                  <p className="text-sm text-green-700">
                    Successfully connected to {walletConnection.network}
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Wallet Address
                    </label>
                    <div className="flex items-center space-x-2 bg-gray-50 p-3 rounded-lg">
                      <span className="flex-1 text-sm font-mono text-gray-900">
                        {formatAddress(walletConnection.address)}
                      </span>
                      <button
                        onClick={copyAddress}
                        className="text-gray-500 hover:text-gray-700 transition-colors duration-200"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                      <a
                        href={`https://etherscan.io/address/${walletConnection.address}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-gray-500 hover:text-gray-700 transition-colors duration-200"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Balance
                    </label>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <span className="text-lg font-semibold text-gray-900">
                        {walletConnection.balance} ETH
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Network
                    </label>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <span className="text-sm text-gray-900 capitalize">
                        {walletConnection.network.replace('-', ' ')}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={disconnectWallet}
                  className="w-full bg-red-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-red-700 transition-colors duration-200"
                >
                  Disconnect Wallet
                </button>
              </div>
            ) : (
              /* Connection Options */
              <div className="space-y-4">
                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5 text-red-600" />
                      <span className="font-medium text-red-800">Connection Failed</span>
                    </div>
                    <p className="text-sm text-red-700 mt-1">{error}</p>
                  </div>
                )}

                <div className="space-y-3">
                  <h3 className="text-lg font-medium text-gray-900">Choose a wallet</h3>
                  
                  <button
                    onClick={() => handleConnect('metamask')}
                    disabled={connecting === 'metamask' || loading}
                    className="w-full flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                        <span className="text-orange-600 font-bold text-sm">M</span>
                      </div>
                      <span className="font-medium text-gray-900">MetaMask</span>
                    </div>
                    {connecting === 'metamask' && (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-orange-600"></div>
                    )}
                  </button>

                  <button
                    onClick={() => handleConnect('binance')}
                    disabled={connecting === 'binance' || loading}
                    className="w-full flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-yellow-300 hover:bg-yellow-50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                        <span className="text-yellow-600 font-bold text-sm">B</span>
                      </div>
                      <span className="font-medium text-gray-900">Binance Wallet</span>
                    </div>
                    {connecting === 'binance' && (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-yellow-600"></div>
                    )}
                  </button>

                  <button
                    onClick={() => handleConnect('walletconnect')}
                    disabled={connecting === 'walletconnect' || loading}
                    className="w-full flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-bold text-sm">W</span>
                      </div>
                      <span className="font-medium text-gray-900">WalletConnect</span>
                    </div>
                    {connecting === 'walletconnect' && (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                    )}
                  </button>
                </div>

                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">
                    Connect your crypto wallet to make secure payments with Bitcoin, Ethereum, and other cryptocurrencies.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};