import React, { useState } from 'react';
import { X, Star, ShoppingCart, Heart, Check } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../hooks/useCart';
import { useCrypto } from '../hooks/useCrypto';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({ product, isOpen, onClose }) => {
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);
  const { addToCart } = useCart();
  const { convertPrice, formatCryptoPrice } = useCrypto();

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  const cryptoPrice = convertPrice(product.priceUSD);
  const originalCryptoPrice = product.originalPriceUSD ? convertPrice(product.originalPriceUSD) : null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="absolute inset-4 bg-white rounded-xl shadow-2xl overflow-hidden">
        <div className="h-full flex flex-col lg:flex-row">
          {/* Image Section */}
          <div className="flex-1 relative">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            
            {/* Badge */}
            {product.badge && (
              <div className={`absolute top-6 left-6 px-3 py-1 rounded-full text-sm font-semibold ${
                product.badge === 'Sale' ? 'bg-red-100 text-red-800' :
                product.badge === 'New' ? 'bg-green-100 text-green-800' :
                'bg-blue-100 text-blue-800'
              }`}>
                {product.badge}
              </div>
            )}
            
            <button
              onClick={onClose}
              className="absolute top-6 right-6 p-2 bg-white rounded-full shadow-lg hover:bg-gray-50 transition-colors duration-200"
            >
              <X className="h-5 w-5 text-gray-600" />
            </button>
          </div>

          {/* Content Section */}
          <div className="flex-1 p-8 overflow-y-auto">
            <div className="max-w-lg">
              {/* Category */}
              <span className="text-sm text-indigo-600 font-medium">{product.category}</span>
              
              {/* Title */}
              <h1 className="text-3xl font-bold text-gray-900 mt-2 mb-4">{product.name}</h1>
              
              {/* Rating */}
              <div className="flex items-center space-x-2 mb-6">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating) 
                          ? 'text-yellow-400 fill-current' 
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-lg font-medium text-gray-900">{product.rating}</span>
                <span className="text-gray-600">({product.reviews} reviews)</span>
              </div>
              
              {/* Price */}
              <div className="space-y-2 mb-6">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl font-bold text-gray-900">
                    {formatPrice(product.priceUSD)}
                  </span>
                  {product.originalPriceUSD && (
                    <span className="text-xl text-gray-500 line-through">
                      {formatPrice(product.originalPriceUSD)}
                    </span>
                  )}
                </div>
                
                {/* Crypto Price */}
                <div className="flex items-center space-x-3">
                  <span className="text-lg font-semibold text-indigo-600">
                    ≈ {formatCryptoPrice(cryptoPrice)}
                  </span>
                  {originalCryptoPrice && (
                    <span className="text-sm text-gray-400 line-through">
                      ≈ {formatCryptoPrice(originalCryptoPrice)}
                    </span>
                  )}
                </div>
              </div>
              
              {/* Description */}
              <p className="text-gray-600 text-lg leading-relaxed mb-6">{product.description}</p>
              
              {/* Features */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Key Features</h3>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <Check className="h-5 w-5 text-green-500" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Stock Status */}
              <div className="flex items-center mb-6">
                <div className={`w-3 h-3 rounded-full mr-2 ${
                  product.inStock ? 'bg-green-400' : 'bg-red-400'
                }`} />
                <span className={`font-medium ${
                  product.inStock ? 'text-green-600' : 'text-red-600'
                }`}>
                  {product.inStock ? 'In Stock' : 'Out of Stock'}
                </span>
              </div>
              
              {/* Quantity and Actions */}
              {product.inStock && (
                <div className="space-y-4">
                  {/* Quantity Selector */}
                  <div className="flex items-center space-x-4">
                    <span className="font-medium text-gray-900">Quantity:</span>
                    <div className="flex items-center border border-gray-200 rounded-lg">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="p-2 hover:bg-gray-100 transition-colors duration-200"
                      >
                        <span className="text-lg font-medium">−</span>
                      </button>
                      <span className="px-4 py-2 text-lg font-medium">{quantity}</span>
                      <button
                        onClick={() => setQuantity(quantity + 1)}
                        className="p-2 hover:bg-gray-100 transition-colors duration-200"
                      >
                        <span className="text-lg font-medium">+</span>
                      </button>
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex space-x-4">
                    <button
                      onClick={handleAddToCart}
                      disabled={addedToCart}
                      className={`flex-1 py-3 px-6 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2 ${
                        addedToCart
                          ? 'bg-green-600 text-white'
                          : 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700'
                      }`}
                    >
                      {addedToCart ? (
                        <>
                          <Check className="h-5 w-5" />
                          <span>Added to Cart!</span>
                        </>
                      ) : (
                        <>
                          <ShoppingCart className="h-5 w-5" />
                          <span>Add to Cart</span>
                        </>
                      )}
                    </button>
                    
                    <button className="p-3 border-2 border-gray-200 rounded-lg hover:border-red-200 hover:text-red-500 transition-all duration-200">
                      <Heart className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};